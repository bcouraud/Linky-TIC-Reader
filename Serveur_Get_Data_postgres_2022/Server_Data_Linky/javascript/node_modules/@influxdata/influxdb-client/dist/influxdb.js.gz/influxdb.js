var influxdb = (function (exports) {
  'use strict';

  /**
   * Creates a chunk combiner instance that uses UTF-8
   * TextDecoder to decode Uint8Arrays into strings.
   */
  function createTextDecoderCombiner() {
      var decoder = new TextDecoder('utf-8');
      return {
          concat: function (first, second) {
              var retVal = new Uint8Array(first.length + second.length);
              retVal.set(first);
              retVal.set(second, first.length);
              return retVal;
          },
          copy: function (chunk, start, end) {
              var retVal = new Uint8Array(end - start);
              retVal.set(chunk.subarray(start, end));
              return retVal;
          },
          toUtf8String: function (chunk, start, end) {
              return decoder.decode(chunk.subarray(start, end));
          },
      };
  }

  /**
   * ChunksToLines is a transformation that accepts Uint8Array instances
   * and emmits strings representing CSV lines.
   * @param target - target to emmit CSV lines to
   * @param chunks - chunk combiner
   * @returns communication obrver to accept Uint8Arrays
   */
  function chunksToLines(target, chunkCombiner) {
      var chunks = chunkCombiner !== null && chunkCombiner !== void 0 ? chunkCombiner : createTextDecoderCombiner();
      var previous;
      var finished = false;
      var quoted = false;
      function bufferReceived(chunk) {
          var index;
          var start = 0;
          if (previous) {
              chunk = chunks.concat(previous, chunk);
              index = previous.length;
          }
          else {
              index = 0;
          }
          while (index < chunk.length) {
              var c = chunk[index];
              if (c === 10) {
                  if (!quoted) {
                      /* do not emit CR+LR or LF line ending */
                      var end = index > 0 && chunk[index - 1] === 13 ? index - 1 : index;
                      // do not emmit more lines if the processing is already finished
                      if (finished) {
                          return;
                      }
                      target.next(chunks.toUtf8String(chunk, start, end));
                      start = index + 1;
                  }
              }
              else if (c === 34 /* " */) {
                  quoted = !quoted;
              }
              index++;
          }
          if (start < index) {
              previous = chunks.copy(chunk, start, index);
          }
          else {
              previous = undefined;
          }
      }
      return {
          next: function (chunk) {
              if (finished)
                  return;
              try {
                  bufferReceived(chunk);
              }
              catch (e) {
                  this.error(e);
              }
          },
          error: function (error) {
              if (!finished) {
                  finished = true;
                  target.error(error);
              }
          },
          complete: function () {
              if (!finished) {
                  if (previous) {
                      target.next(chunks.toUtf8String(previous, 0, previous.length));
                  }
                  finished = true;
                  target.complete();
              }
          },
          useCancellable: function (cancellable) {
              if (target.useCancellable) {
                  // eslint-disable-next-line @typescript-eslint/no-this-alias
                  var self_1 = this;
                  target.useCancellable({
                      cancel: function () {
                          cancellable.cancel();
                          previous = undefined; // do not emit more lines
                          self_1.complete();
                      },
                      isCancelled: function () {
                          return cancellable.isCancelled();
                      },
                  });
              }
          },
      };
  }

  /**
   * Optimized tokenizer of a single CSV line.
   */
  var LineSplitter = /** @class */ (function () {
      function LineSplitter() {
          this._reuse = false;
      }
      Object.defineProperty(LineSplitter.prototype, "reuse", {
          /**
           * Reuse returned array between consecutive calls.
           */
          get: function () {
              return this._reuse;
          },
          set: function (val) {
              if (val && !this.reusedValues) {
                  this.reusedValues = new Array(10);
              }
              this._reuse = val;
          },
          enumerable: false,
          configurable: true
      });
      /**
       * Sets the reuse flag and returns this.
       */
      LineSplitter.prototype.withReuse = function () {
          this.reuse = true;
          return this;
      };
      /**
       * Splits the supplied line to elements that are separated by
       * comma with values possibly escaped within double quotes ("value")
       * @param line - line
       * @returns array of splitted parts
       */
      LineSplitter.prototype.splitLine = function (line) {
          if (line === null || line === undefined) {
              this.lastSplitLength = 0;
              return [];
          }
          var quoteCount = 0;
          var startIndex = 0;
          var values = this._reuse ? this.reusedValues : [];
          var count = 0;
          for (var i = 0; i < line.length; i++) {
              var c = line[i];
              if (c === ',') {
                  if (quoteCount % 2 === 0) {
                      var val_1 = this.getValue(line, startIndex, i, quoteCount);
                      if (this._reuse) {
                          values[count++] = val_1;
                      }
                      else {
                          values.push(val_1);
                      }
                      startIndex = i + 1;
                      quoteCount = 0;
                  }
              }
              else if (c === '"') {
                  quoteCount++;
              }
          }
          var val = this.getValue(line, startIndex, line.length, quoteCount);
          if (this._reuse) {
              values[count] = val;
              this.lastSplitLength = count + 1;
          }
          else {
              values.push(val);
              this.lastSplitLength = values.length;
          }
          return values;
      };
      LineSplitter.prototype.getValue = function (line, start, end, quoteCount) {
          if (start === line.length) {
              return '';
          }
          else if (quoteCount === 0) {
              return line.substring(start, end);
          }
          else if (quoteCount === 2) {
              return line.substring(start + 1, end - 1);
          }
          else {
              // quoteCount >= 4
              return line.substring(start + 1, end - 1).replace(/""/gi, '"');
          }
      };
      return LineSplitter;
  }());

  var identity = function (x) { return x; };
  /**
   * A dictionary of serializers of particular types returned by a flux query.
   * See {@link https://docs.influxdata.com/influxdb/v2.1/reference/syntax/annotated-csv/#data-types }
   */
  var typeSerializers = {
      boolean: function (x) { return x === 'true'; },
      unsignedLong: function (x) { return (x === '' ? null : +x); },
      long: function (x) { return (x === '' ? null : +x); },
      double: function (x) {
          switch (x) {
              case '':
                  return null;
              case '+Inf':
                  return Number.POSITIVE_INFINITY;
              case '-Inf':
                  return Number.NEGATIVE_INFINITY;
              default:
                  return +x;
          }
      },
      string: identity,
      base64Binary: identity,
      duration: function (x) { return (x === '' ? null : x); },
      'dateTime:RFC3339': function (x) { return (x === '' ? null : x); },
  };
  /**
   * FluxTableColumn implementation.
   */
  var FluxTableColumnImpl = /** @class */ (function () {
      function FluxTableColumnImpl() {
      }
      FluxTableColumnImpl.prototype.get = function (row) {
          var _a;
          var val = row[this.index];
          if ((val === '' || val === undefined) && this.defaultValue) {
              val = this.defaultValue;
          }
          return ((_a = typeSerializers[this.dataType]) !== null && _a !== void 0 ? _a : identity)(val);
      };
      return FluxTableColumnImpl;
  }());
  var UNKNOWN_COLUMN = Object.freeze({
      label: '',
      dataType: '',
      group: false,
      defaultValue: '',
      index: Number.MAX_SAFE_INTEGER,
      get: function () { return undefined; },
  });
  /**
   * Creates a new flux table column.
   * @returns column instance
   */
  function newFluxTableColumn() {
      return new FluxTableColumnImpl();
  }
  /**
   * Creates a flux table column from a partial FluxTableColumn.
   * @param object - source object
   * @returns column instance
   */
  function createFluxTableColumn(object) {
      var _a, _b;
      var retVal = new FluxTableColumnImpl();
      retVal.label = String(object.label);
      retVal.dataType = object.dataType;
      retVal.group = Boolean(object.group);
      retVal.defaultValue = (_a = object.defaultValue) !== null && _a !== void 0 ? _a : '';
      retVal.index = (_b = object.index) !== null && _b !== void 0 ? _b : 0;
      return retVal;
  }

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  /* global Reflect, Promise */

  var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
      return extendStatics(d, b);
  };

  function __extends(d, b) {
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }

  var __assign = function() {
      __assign = Object.assign || function __assign(t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
              s = arguments[i];
              for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
          return t;
      };
      return __assign.apply(this, arguments);
  };

  function __rest(s, e) {
      var t = {};
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
          t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  }

  function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
          function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  }

  function __generator(thisArg, body) {
      var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
      function verb(n) { return function (v) { return step([n, v]); }; }
      function step(op) {
          if (f) throw new TypeError("Generator is already executing.");
          while (_) try {
              if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
              if (y = 0, t) op = [op[0] & 2, t.value];
              switch (op[0]) {
                  case 0: case 1: t = op; break;
                  case 4: _.label++; return { value: op[1], done: false };
                  case 5: _.label++; y = op[1]; op = [0]; continue;
                  case 7: op = _.ops.pop(); _.trys.pop(); continue;
                  default:
                      if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                      if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                      if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                      if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                      if (t[2]) _.ops.pop();
                      _.trys.pop(); continue;
              }
              op = body.call(thisArg, _);
          } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
          if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
      }
  }

  var retriableStatusCodes = [404, 408, 425, 429, 500, 502, 503, 504];
  /** isStatusCodeRetriable checks whether the supplied HTTP status code is retriable. */
  function isStatusCodeRetriable(statusCode) {
      return retriableStatusCodes.includes(statusCode);
  }
  /** IllegalArgumentError is thrown when illegal argument is supplied. */
  var IllegalArgumentError = /** @class */ (function (_super) {
      __extends(IllegalArgumentError, _super);
      /* istanbul ignore next */
      function IllegalArgumentError(message) {
          var _this = _super.call(this, message) || this;
          _this.name = 'IllegalArgumentError';
          Object.setPrototypeOf(_this, IllegalArgumentError.prototype);
          return _this;
      }
      return IllegalArgumentError;
  }(Error));
  /**
   * A general HTTP error.
   */
  var HttpError = /** @class */ (function (_super) {
      __extends(HttpError, _super);
      /* istanbul ignore next because of super() not being covered*/
      function HttpError(statusCode, statusMessage, body, retryAfter, contentType, message) {
          var _this = _super.call(this) || this;
          _this.statusCode = statusCode;
          _this.statusMessage = statusMessage;
          _this.body = body;
          _this.contentType = contentType;
          Object.setPrototypeOf(_this, HttpError.prototype);
          if (message) {
              _this.message = message;
          }
          else if (body) {
              if (contentType === null || contentType === void 0 ? void 0 : contentType.startsWith('application/json')) {
                  try {
                      _this.json = JSON.parse(body);
                      _this.message = _this.json.message;
                      _this.code = _this.json.code;
                  }
                  catch (e) {
                      // silently ignore, body string is still available
                  }
              }
              if (!_this.message) {
                  _this.message = "".concat(statusCode, " ").concat(statusMessage, " : ").concat(body);
              }
          }
          else {
              _this.message = "".concat(statusCode, " ").concat(statusMessage);
          }
          _this.name = 'HttpError';
          _this.setRetryAfter(retryAfter);
          return _this;
      }
      HttpError.prototype.setRetryAfter = function (retryAfter) {
          if (typeof retryAfter === 'string') {
              // try to parse the supplied number as milliseconds
              if (/^[0-9]+$/.test(retryAfter)) {
                  this._retryAfter = parseInt(retryAfter);
              }
              else {
                  this._retryAfter = 0;
              }
          }
          else {
              this._retryAfter = 0;
          }
      };
      HttpError.prototype.canRetry = function () {
          return isStatusCodeRetriable(this.statusCode);
      };
      HttpError.prototype.retryAfter = function () {
          return this._retryAfter;
      };
      return HttpError;
  }(Error));
  //see https://nodejs.org/api/errors.html
  var RETRY_CODES = [
      'ECONNRESET',
      'ENOTFOUND',
      'ESOCKETTIMEDOUT',
      'ETIMEDOUT',
      'ECONNREFUSED',
      'EHOSTUNREACH',
      'EPIPE',
  ];
  /**
   * Tests the error in order to know if an HTTP call can be retried.
   * @param error - error to test
   * @returns true for a retriable error
   */
  function canRetryHttpCall(error) {
      if (!error) {
          return false;
      }
      else if (typeof error.canRetry === 'function') {
          return !!error.canRetry();
      }
      else if (error.code && RETRY_CODES.includes(error.code)) {
          return true;
      }
      return false;
  }
  /**
   * Gets retry delay from the supplied error, possibly using random number up to retryJitter.
   */
  function getRetryDelay(error, retryJitter) {
      if (!error) {
          return 0;
      }
      else {
          var retVal = void 0;
          if (typeof error.retryAfter === 'function') {
              return error.retryAfter();
          }
          else {
              retVal = 0;
          }
          if (retryJitter && retryJitter > 0) {
              return retVal + Math.round(Math.random() * retryJitter);
          }
          else {
              return retVal;
          }
      }
  }
  /** RequestTimedOutError indicates request timeout in the communication with the server */
  var RequestTimedOutError = /** @class */ (function (_super) {
      __extends(RequestTimedOutError, _super);
      /* istanbul ignore next because of super() not being covered */
      function RequestTimedOutError() {
          var _this = _super.call(this) || this;
          Object.setPrototypeOf(_this, RequestTimedOutError.prototype);
          _this.name = 'RequestTimedOutError';
          _this.message = 'Request timed out';
          return _this;
      }
      RequestTimedOutError.prototype.canRetry = function () {
          return true;
      };
      RequestTimedOutError.prototype.retryAfter = function () {
          return 0;
      };
      return RequestTimedOutError;
  }(Error));
  /** AbortError indicates that the communication with the server was aborted */
  var AbortError = /** @class */ (function (_super) {
      __extends(AbortError, _super);
      /* istanbul ignore next because of super() not being covered */
      function AbortError() {
          var _this = _super.call(this) || this;
          _this.name = 'AbortError';
          Object.setPrototypeOf(_this, AbortError.prototype);
          _this.message = 'Response aborted';
          return _this;
      }
      AbortError.prototype.canRetry = function () {
          return true;
      };
      AbortError.prototype.retryAfter = function () {
          return 0;
      };
      return AbortError;
  }(Error));

  /**
   * serializeDateTimeAsDate changes type serializers to return JavaScript Date instances
   * for 'dateTime:RFC3339' query result data type. Empty value is converted to null.
   * @remarks
   * Please note that the result has millisecond precision whereas InfluxDB returns dateTime
   * in nanosecond precision.
   */
  function serializeDateTimeAsDate() {
      typeSerializers['dateTime:RFC3339'] = function (x) {
          return x === '' ? null : new Date(Date.parse(x));
      };
  }
  /**
   * serializeDateTimeAsNumber changes type serializers to return milliseconds since epoch
   * for 'dateTime:RFC3339' query result data type. Empty value is converted to null.
   * @remarks
   * Please note that the result has millisecond precision whereas InfluxDB returns dateTime
   * in nanosecond precision.
   */
  function serializeDateTimeAsNumber() {
      typeSerializers['dateTime:RFC3339'] = function (x) {
          return x === '' ? null : Date.parse(x);
      };
  }
  /**
   * serializeDateTimeAsString changes type serializers to return string values
   * for `dateTime:RFC3339` query result data type.  Empty value is converted to null.
   */
  function serializeDateTimeAsString() {
      typeSerializers['dateTime:RFC3339'] = function (x) {
          return x === '' ? null : x;
      };
  }
  /**
   * FluxTableMetaData Implementation.
   */
  var FluxTableMetaDataImpl = /** @class */ (function () {
      function FluxTableMetaDataImpl(columns) {
          columns.forEach(function (col, i) { return (col.index = i); });
          this.columns = columns;
      }
      FluxTableMetaDataImpl.prototype.column = function (label, errorOnMissingColumn) {
          if (errorOnMissingColumn === void 0) { errorOnMissingColumn = true; }
          for (var i = 0; i < this.columns.length; i++) {
              var col = this.columns[i];
              if (col.label === label)
                  return col;
          }
          if (errorOnMissingColumn) {
              throw new IllegalArgumentError("Column ".concat(label, " not found!"));
          }
          return UNKNOWN_COLUMN;
      };
      FluxTableMetaDataImpl.prototype.toObject = function (row) {
          var acc = {};
          for (var i = 0; i < this.columns.length && i < row.length; i++) {
              var column = this.columns[i];
              acc[column.label] = column.get(row);
          }
          return acc;
      };
      FluxTableMetaDataImpl.prototype.get = function (row, column) {
          return this.column(column, false).get(row);
      };
      return FluxTableMetaDataImpl;
  }());
  /**
   * Created FluxTableMetaData from the columns supplied.
   * @param columns -  columns
   * @returns - instance
   */
  function createFluxTableMetaData(columns) {
      return new FluxTableMetaDataImpl(columns);
  }

  /**
   * linesToTables creates a transformationthat accepts (flux) annotated CSV lines
   * and emits rows together with table metadata.
   */
  function linesToTables(consumer) {
      var splitter = new LineSplitter().withReuse();
      var columns;
      var expectMeta = true;
      var firstColumnIndex = 0;
      var lastMeta;
      return {
          error: function (error) {
              consumer.error(error);
          },
          next: function (line) {
              if (line === '') {
                  expectMeta = true;
                  columns = undefined;
              }
              else {
                  var values = splitter.splitLine(line);
                  var size = splitter.lastSplitLength;
                  if (expectMeta) {
                      // create columns
                      if (!columns) {
                          columns = new Array(size);
                          for (var i = 0; i < size; i++) {
                              columns[i] = newFluxTableColumn();
                          }
                      }
                      if (!values[0].startsWith('#')) {
                          // fill in column names
                          if (values[0] === '') {
                              firstColumnIndex = 1;
                              columns = columns.slice(1);
                          }
                          else {
                              firstColumnIndex = 0;
                          }
                          for (var i = firstColumnIndex; i < size; i++) {
                              columns[i - firstColumnIndex].label = values[i];
                          }
                          lastMeta = createFluxTableMetaData(columns);
                          expectMeta = false;
                      }
                      else if (values[0] === '#datatype') {
                          for (var i = 1; i < size; i++) {
                              columns[i].dataType = values[i];
                          }
                      }
                      else if (values[0] === '#default') {
                          for (var i = 1; i < size; i++) {
                              columns[i].defaultValue = values[i];
                          }
                      }
                      else if (values[0] === '#group') {
                          for (var i = 1; i < size; i++) {
                              columns[i].group = values[i][0] === 't';
                          }
                      }
                  }
                  else {
                      consumer.next(values.slice(firstColumnIndex, size), lastMeta);
                  }
              }
          },
          complete: function () {
              consumer.complete();
          },
          useCancellable: function (cancellable) {
              if (consumer.useCancellable)
                  consumer.useCancellable(cancellable);
          },
      };
  }

  /**
   * StringToLines is a transformation that emmits strings for each CSV
   * line in the supplied source string.
   * @param source - source string
   * @param target - target to emmit CSV lines to
   * @returns communication obrver to accept Uint8Arrays
   */
  function stringToLines(source, target) {
      var quoted = false;
      var start = 0;
      var index = 0;
      while (index < source.length) {
          var c = source.charCodeAt(index);
          if (c === 10) {
              if (!quoted) {
                  /* do not emit CR+LR or LF line ending */
                  var end = index > 0 && source.charCodeAt(index - 1) === 13 ? index - 1 : index;
                  // do not emmit more lines if the processing is already finished
                  target.next(source.substring(start, end));
                  start = index + 1;
              }
          }
          else if (c === 34 /* " */) {
              quoted = !quoted;
          }
          index++;
      }
      if (start < index) {
          target.next(source.substring(start, index));
      }
      target.complete();
  }

  /** default connection options */
  var DEFAULT_ConnectionOptions = {
      timeout: 10000,
  };
  /** default RetryDelayStrategyOptions */
  var DEFAULT_RetryDelayStrategyOptions = {
      retryJitter: 200,
      minRetryDelay: 5000,
      maxRetryDelay: 125000,
      exponentialBase: 5,
      randomRetry: true,
  };
  /** default writeOptions */
  var DEFAULT_WriteOptions = {
      batchSize: 1000,
      maxBatchBytes: 50000000,
      flushInterval: 60000,
      writeFailed: function () { },
      writeSuccess: function () { },
      maxRetries: 5,
      maxRetryTime: 180000,
      maxBufferLines: 32000,
      // a copy of DEFAULT_RetryDelayStrategyOptions, so that DEFAULT_WriteOptions could be tree-shaken
      retryJitter: 200,
      minRetryDelay: 5000,
      maxRetryDelay: 125000,
      exponentialBase: 2,
      gzipThreshold: 1000,
      randomRetry: true,
  };

  function createEscaper(characters, replacements) {
      return function (value) {
          var retVal = '';
          var from = 0;
          var i = 0;
          while (i < value.length) {
              var found = characters.indexOf(value[i]);
              if (found >= 0) {
                  retVal += value.substring(from, i);
                  retVal += replacements[found];
                  from = i + 1;
              }
              i++;
          }
          if (from == 0) {
              return value;
          }
          else if (from < value.length) {
              retVal += value.substring(from, value.length);
          }
          return retVal;
      };
  }
  function createQuotedEscaper(characters, replacements) {
      var escaper = createEscaper(characters, replacements);
      return function (value) { return '"' + escaper(value) + '"'; };
  }
  /**
   * Provides functions escape specific parts in InfluxDB line protocol.
   */
  var escape = {
      /**
       * Measurement escapes measurement names.
       */
      measurement: createEscaper(', \n\r\t', ['\\,', '\\ ', '\\n', '\\r', '\\t']),
      /**
       * Quoted escapes quoted values, such as database names.
       */
      quoted: createQuotedEscaper('"\\', ['\\"', '\\\\']),
      /**
       * TagEscaper escapes tag keys, tag values, and field keys.
       */
      tag: createEscaper(', =\n\r\t', ['\\,', '\\ ', '\\=', '\\n', '\\r', '\\t']),
  };

  var zeroPadding = '000000000';
  function useProcessHrtime(use) {
      /* istanbul ignore else */
      {
          return false;
      }
  }
  var lastMillis = Date.now();
  var stepsInMillis = 0;
  function nanos() {
      {
          var millis_2 = Date.now();
          if (millis_2 !== lastMillis) {
              lastMillis = millis_2;
              stepsInMillis = 0;
          }
          else {
              stepsInMillis++;
          }
          var nanos_2 = String(stepsInMillis);
          return String(millis_2) + zeroPadding.substr(0, 6 - nanos_2.length) + nanos_2;
      }
  }
  function micros() {
      {
          return String(Date.now()) + zeroPadding.substr(0, 3);
      }
  }
  function millis() {
      return String(Date.now());
  }
  function seconds() {
      return String(Math.floor(Date.now() / 1000));
  }
  /**
   * Exposes functions that creates strings that represent a timestamp that
   * can be used in the line protocol. Micro and nano timestamps are emulated
   * depending on the js platform in use.
   */
  var currentTime = {
      s: seconds,
      ms: millis,
      us: micros,
      ns: nanos,
      seconds: seconds,
      millis: millis,
      micros: micros,
      nanos: nanos,
  };
  /**
   * dateToProtocolTimestamp provides converters for JavaScript Date to InfluxDB Write Protocol Timestamp. Keys are supported precisions.
   */
  var dateToProtocolTimestamp = {
      s: function (d) { return "".concat(Math.floor(d.getTime() / 1000)); },
      ms: function (d) { return "".concat(d.getTime()); },
      us: function (d) { return "".concat(d.getTime(), "000"); },
      ns: function (d) { return "".concat(d.getTime(), "000000"); },
  };
  /**
   * convertTimeToNanos converts Point's timestamp to a string.
   * @param value - supported timestamp value
   * @returns line protocol value
   */
  function convertTimeToNanos(value) {
      if (value === undefined) {
          return nanos();
      }
      else if (typeof value === 'string') {
          return value.length > 0 ? value : undefined;
      }
      else if (value instanceof Date) {
          return "".concat(value.getTime(), "000000");
      }
      else if (typeof value === 'number') {
          return String(Math.floor(value));
      }
      else {
          return String(value);
      }
  }

  /**
   * Logger that logs to console.out
   */
  var consoleLogger = {
      error: function (message, error) {
          // eslint-disable-next-line no-console
          console.error('ERROR: ' + message, error ? error : '');
      },
      warn: function (message, error) {
          // eslint-disable-next-line no-console
          console.warn('WARN: ' + message, error ? error : '');
      },
  };
  var provider = consoleLogger;
  var Log = {
      error: function (message, error) {
          provider.error(message, error);
      },
      warn: function (message, error) {
          provider.warn(message, error);
      },
  };
  /**
   * Sets custom logger.
   * @param logger - logger to use
   * @returns previous logger
   */
  function setLogger(logger) {
      var previous = provider;
      provider = logger;
      return previous;
  }

  /** Property that offers a function that returns flux-sanitized value of an object.  */
  var FLUX_VALUE = Symbol('FLUX_VALUE');
  var FluxParameter = /** @class */ (function () {
      function FluxParameter(fluxValue) {
          this.fluxValue = fluxValue;
      }
      FluxParameter.prototype.toString = function () {
          return this.fluxValue;
      };
      FluxParameter.prototype[FLUX_VALUE] = function () {
          return this.fluxValue;
      };
      return FluxParameter;
  }());
  /**
   * Checks if the supplied object is FluxParameterLike
   * @param value - any value
   * @returns true if it is
   */
  function isFluxParameterLike(value) {
      return typeof value === 'object' && typeof value[FLUX_VALUE] === 'function';
  }
  /**
   * Escapes content of the supplied string so it can be wrapped into double qoutes
   * to become a [flux string literal](https://docs.influxdata.com/flux/v0.65/language/lexical-elements/#string-literals).
   * @param value - string value
   * @returns sanitized string
   */
  function sanitizeString(value) {
      if (value === null || value === undefined)
          return '';
      value = value.toString();
      var retVal = undefined;
      var i = 0;
      function prepareRetVal() {
          if (retVal === undefined) {
              retVal = value.substring(0, i);
          }
      }
      for (; i < value.length; i++) {
          var c = value.charAt(i);
          switch (c) {
              case '\r':
                  prepareRetVal();
                  retVal += '\\r';
                  break;
              case '\n':
                  prepareRetVal();
                  retVal += '\\n';
                  break;
              case '\t':
                  prepareRetVal();
                  retVal += '\\t';
                  break;
              case '"':
              case '\\':
                  prepareRetVal();
                  retVal = retVal + '\\' + c;
                  break;
              case '$':
                  // escape ${
                  if (i + 1 < value.length && value.charAt(i + 1) === '{') {
                      prepareRetVal();
                      i++;
                      retVal += '\\${';
                      break;
                  }
                  // append $
                  if (retVal != undefined) {
                      retVal += c;
                  }
                  break;
              default:
                  if (retVal != undefined) {
                      retVal += c;
                  }
          }
      }
      if (retVal !== undefined) {
          return retVal;
      }
      return value;
  }
  /**
   * Creates a flux string literal.
   */
  function fluxString(value) {
      return new FluxParameter("\"".concat(sanitizeString(value), "\""));
  }
  /**
   * Sanitizes float value to avoid injections.
   * @param value - InfluxDB float literal
   * @returns sanitized float value
   * @throws Error if the the value cannot be sanitized
   */
  function sanitizeFloat(value) {
      var val = Number(value);
      if (!isFinite(val)) {
          if (typeof value === 'number') {
              return "float(v: \"".concat(val, "\")");
          }
          throw new Error("not a flux float: ".concat(value));
      }
      // try to return a flux float literal if possible
      // https://docs.influxdata.com/flux/v0.x/data-types/basic/float/#float-syntax
      var strVal = val.toString();
      var hasDot = false;
      for (var _i = 0, strVal_1 = strVal; _i < strVal_1.length; _i++) {
          var c = strVal_1[_i];
          if ((c >= '0' && c <= '9') || c == '-')
              continue;
          if (c === '.') {
              hasDot = true;
              continue;
          }
          return "float(v: \"".concat(strVal, "\")");
      }
      return hasDot ? strVal : strVal + '.0';
  }
  /**
   * Creates a flux float literal.
   */
  function fluxFloat(value) {
      return new FluxParameter(sanitizeFloat(value));
  }
  /**
   * Sanitizes integer value to avoid injections.
   * @param value - InfluxDB integer literal
   * @returns sanitized integer value
   * @throws Error if the the value cannot be sanitized
   */
  function sanitizeInteger(value) {
      // https://docs.influxdata.com/flux/v0.x/data-types/basic/int/
      // Min value: -9223372036854775808
      // Max value: 9223372036854775807
      // "9223372036854775807".length === 19
      var strVal = String(value);
      var negative = strVal.startsWith('-');
      var val = negative ? strVal.substring(1) : strVal;
      if (val.length === 0 || val.length > 19) {
          throw new Error("not a flux integer: ".concat(strVal));
      }
      for (var _i = 0, val_1 = val; _i < val_1.length; _i++) {
          var c = val_1[_i];
          if (c < '0' || c > '9')
              throw new Error("not a flux integer: ".concat(strVal));
      }
      if (val.length === 19) {
          if (negative && val > '9223372036854775808') {
              throw new Error("flux integer out of bounds: ".concat(strVal));
          }
          if (!negative && val > '9223372036854775807') {
              throw new Error("flux integer out of bounds: ".concat(strVal));
          }
      }
      return strVal;
  }
  /**
   * Creates a flux integer literal.
   */
  function fluxInteger(value) {
      return new FluxParameter(sanitizeInteger(value));
  }
  function sanitizeDateTime(value) {
      return "time(v: \"".concat(sanitizeString(value), "\")");
  }
  /**
   * Creates flux date-time literal.
   */
  function fluxDateTime(value) {
      return new FluxParameter(sanitizeDateTime(value));
  }
  /**
   * Creates flux date-time literal.
   */
  function fluxDuration(value) {
      return new FluxParameter("duration(v: \"".concat(sanitizeString(value), "\")"));
  }
  function sanitizeRegExp(value) {
      if (value instanceof RegExp) {
          return value.toString();
      }
      return new RegExp(value).toString();
  }
  /**
   * Creates flux regexp literal out of a regular expression. See
   * https://docs.influxdata.com/flux/v0.x/data-types/basic/regexp/#regular-expression-syntax
   * for details.
   */
  function fluxRegExp(value) {
      // let the server decide if a regexp can be parsed
      return new FluxParameter(sanitizeRegExp(value));
  }
  /**
   * Creates flux boolean literal.
   */
  function fluxBool(value) {
      if (value === 'true' || value === 'false') {
          return new FluxParameter(value);
      }
      return new FluxParameter((!!value).toString());
  }
  /**
   * Assumes that the supplied value is flux expression or literal that does not need sanitizing.
   *
   * @param value - any value
   * @returns the supplied value as-is
   */
  function fluxExpression(value) {
      return new FluxParameter(String(value));
  }
  /**
   * Escapes content of the supplied parameter so that it can be safely embedded into flux query.
   * @param value - parameter value
   * @returns sanitized flux value or an empty string if it cannot be converted
   */
  function toFluxValue(value) {
      if (value === undefined) {
          return '';
      }
      else if (value === null) {
          return 'null';
      }
      else if (typeof value === 'boolean') {
          return value.toString();
      }
      else if (typeof value === 'string') {
          return "\"".concat(sanitizeString(value), "\"");
      }
      else if (typeof value === 'number') {
          if (Number.isSafeInteger(value)) {
              return sanitizeInteger(value);
          }
          return sanitizeFloat(value);
      }
      else if (typeof value === 'object') {
          if (typeof value[FLUX_VALUE] === 'function') {
              return value[FLUX_VALUE]();
          }
          else if (value instanceof Date) {
              return value.toISOString();
          }
          else if (value instanceof RegExp) {
              return sanitizeRegExp(value);
          }
          else if (Array.isArray(value)) {
              return "[".concat(value.map(toFluxValue).join(','), "]");
          }
      }
      else if (typeof value === 'bigint') {
          return "".concat(value, ".0");
      }
      // use toString value for unrecognized object, symbol
      return toFluxValue(value.toString());
  }
  /**
   * Flux is a tagged template that sanitizes supplied parameters
   * to avoid injection attacks in flux.
   */
  function flux(strings) {
      var values = [];
      for (var _i = 1; _i < arguments.length; _i++) {
          values[_i - 1] = arguments[_i];
      }
      if (strings.length == 1 && values.length === 0) {
          return fluxExpression(strings[0]); // the simplest case
      }
      var parts = new Array(strings.length + values.length);
      var partIndex = 0;
      for (var i = 0; i < strings.length; i++) {
          var text = strings[i];
          parts[partIndex++] = text;
          if (i < values.length) {
              var val = values[i];
              var sanitized = void 0;
              if (text.endsWith('"') &&
                  i + 1 < strings.length &&
                  strings[i + 1].startsWith('"')) {
                  // parameter is wrapped into flux double quotes
                  sanitized = sanitizeString(val);
              }
              else {
                  sanitized = toFluxValue(val);
                  if (sanitized === '') {
                      // do not allow to insert empty strings, unless it is FluxParameterLike
                      if (!isFluxParameterLike(val)) {
                          throw new Error("Unsupported parameter literal '".concat(val, "' at index: ").concat(i, ", type: ").concat(typeof val));
                      }
                  }
              }
              parts[partIndex++] = sanitized;
          }
          else if (i < strings.length - 1) {
              throw new Error('Too few parameters supplied!');
          }
      }
      // return flux expression so that flux can be embedded into another flux as-is
      return fluxExpression(parts.join(''));
  }

  /* Observable interop typing. Taken from https://github.com/ReactiveX/rxjs */
  /** Symbol.observable or a string "\@\@observable". Used for interop */
  var symbolObservable = (function () {
      return (typeof Symbol === 'function' && Symbol.observable) || '@@observable';
  })();

  /**
   * Point defines values of a single measurement.
   */
  var Point = /** @class */ (function () {
      /**
       * Create a new Point with specified a measurement name.
       *
       * @param measurementName - the measurement name
       */
      function Point(measurementName) {
          this.tags = {};
          /** escaped field values */
          this.fields = {};
          if (measurementName)
              this.name = measurementName;
      }
      /**
       * Sets point's measurement.
       *
       * @param name - measurement name
       * @returns this
       */
      Point.prototype.measurement = function (name) {
          this.name = name;
          return this;
      };
      /**
       * Adds a tag. The caller has to ensure that both name and value are not empty
       * and do not end with backslash.
       *
       * @param name - tag name
       * @param value - tag value
       * @returns this
       */
      Point.prototype.tag = function (name, value) {
          this.tags[name] = value;
          return this;
      };
      /**
       * Adds a boolean field.
       *
       * @param field - field name
       * @param value - field value
       * @returns this
       */
      Point.prototype.booleanField = function (name, value) {
          this.fields[name] = value ? 'T' : 'F';
          return this;
      };
      /**
       * Adds an integer field.
       *
       * @param name - field name
       * @param value - field value
       * @returns this
       * @throws NaN or out of int64 range value is supplied
       */
      Point.prototype.intField = function (name, value) {
          var val;
          if (typeof value === 'number') {
              val = value;
          }
          else {
              val = parseInt(String(value));
          }
          if (isNaN(val) || val <= -9223372036854776e3 || val >= 9223372036854776e3) {
              throw new Error("invalid integer value for field '".concat(name, "': '").concat(value, "'!"));
          }
          this.fields[name] = "".concat(Math.floor(val), "i");
          return this;
      };
      /**
       * Adds an unsigned integer field.
       *
       * @param name - field name
       * @param value - field value
       * @returns this
       * @throws NaN out of range value is supplied
       */
      Point.prototype.uintField = function (name, value) {
          if (typeof value === 'number') {
              if (isNaN(value) || value < 0 || value > Number.MAX_SAFE_INTEGER) {
                  throw new Error("uint value for field '".concat(name, "' out of range: ").concat(value));
              }
              this.fields[name] = "".concat(Math.floor(value), "u");
          }
          else {
              var strVal = String(value);
              for (var i = 0; i < strVal.length; i++) {
                  var code = strVal.charCodeAt(i);
                  if (code < 48 || code > 57) {
                      throw new Error("uint value has an unsupported character at pos ".concat(i, ": ").concat(value));
                  }
              }
              if (strVal.length > 20 ||
                  (strVal.length === 20 &&
                      strVal.localeCompare('18446744073709551615') > 0)) {
                  throw new Error("uint value for field '".concat(name, "' out of range: ").concat(strVal));
              }
              this.fields[name] = "".concat(strVal, "u");
          }
          return this;
      };
      /**
       * Adds a number field.
       *
       * @param name - field name
       * @param value - field value
       * @returns this
       * @throws NaN/Infinity/-Infinity is supplied
       */
      Point.prototype.floatField = function (name, value) {
          var val;
          if (typeof value === 'number') {
              val = value;
          }
          else {
              val = parseFloat(value);
          }
          if (!isFinite(val)) {
              throw new Error("invalid float value for field '".concat(name, "': ").concat(value));
          }
          this.fields[name] = String(val);
          return this;
      };
      /**
       * Adds a string field.
       *
       * @param name - field name
       * @param value - field value
       * @returns this
       */
      Point.prototype.stringField = function (name, value) {
          if (value !== null && value !== undefined) {
              if (typeof value !== 'string')
                  value = String(value);
              this.fields[name] = escape.quoted(value);
          }
          return this;
      };
      /**
       * Sets point timestamp. Timestamp can be specified as a Date (preferred), number, string
       * or an undefined value. An undefined value instructs to assign a local timestamp using
       * the client's clock. An empty string can be used to let the server assign
       * the timestamp. A number value represents time as a count of time units since epoch, the
       * exact time unit then depends on the {@link InfluxDB.getWriteApi | precision} of the API
       * that writes the point.
       *
       * Beware that the current time in nanoseconds can't precisely fit into a JS number,
       * which can hold at most 2^53 integer number. Nanosecond precision numbers are thus supplied as
       * a (base-10) string. An application can also use ES2020 BigInt to represent nanoseconds,
       * BigInt's `toString()` returns the required high-precision string.
       *
       * Note that InfluxDB requires the timestamp to fit into int64 data type.
       *
       * @param value - point time
       * @returns this
       */
      Point.prototype.timestamp = function (value) {
          this.time = value;
          return this;
      };
      /**
       * Creates an InfluxDB protocol line out of this instance.
       * @param settings - settings control serialization of a point timestamp and can also add default tags,
       * nanosecond timestamp precision is used when no `settings` or no `settings.convertTime` is supplied.
       * @returns an InfluxDB protocol line out of this instance
       */
      Point.prototype.toLineProtocol = function (settings) {
          var _this = this;
          if (!this.name)
              return undefined;
          var fieldsLine = '';
          Object.keys(this.fields)
              .sort()
              .forEach(function (x) {
              if (x) {
                  var val = _this.fields[x];
                  if (fieldsLine.length > 0)
                      fieldsLine += ',';
                  fieldsLine += "".concat(escape.tag(x), "=").concat(val);
              }
          });
          if (fieldsLine.length === 0)
              return undefined; // no fields present
          var tagsLine = '';
          var tags = settings && settings.defaultTags
              ? __assign(__assign({}, settings.defaultTags), this.tags) : this.tags;
          Object.keys(tags)
              .sort()
              .forEach(function (x) {
              if (x) {
                  var val = tags[x];
                  if (val) {
                      tagsLine += ',';
                      tagsLine += "".concat(escape.tag(x), "=").concat(escape.tag(val));
                  }
              }
          });
          var time = this.time;
          if (settings && settings.convertTime) {
              time = settings.convertTime(time);
          }
          else {
              time = convertTimeToNanos(time);
          }
          return "".concat(escape.measurement(this.name)).concat(tagsLine, " ").concat(fieldsLine).concat(time !== undefined ? ' ' + time : '');
      };
      Point.prototype.toString = function () {
          var line = this.toLineProtocol(undefined);
          return line ? line : "invalid point: ".concat(JSON.stringify(this, undefined));
      };
      return Point;
  }());

  /**
   * Applies a variant of exponential backoff with initial and max delay and a random
   * jitter delay. It also respects `retry delay` when specified together with an error.
   */
  var RetryStrategyImpl = /** @class */ (function () {
      function RetryStrategyImpl(options) {
          this.options = __assign(__assign({}, DEFAULT_RetryDelayStrategyOptions), options);
          this.success();
      }
      RetryStrategyImpl.prototype.nextDelay = function (error, failedAttempts) {
          var delay = getRetryDelay(error);
          if (delay && delay > 0) {
              return delay + Math.round(Math.random() * this.options.retryJitter);
          }
          else {
              if (failedAttempts && failedAttempts > 0) {
                  // compute delay
                  if (this.options.randomRetry) {
                      // random delay between deterministic delays
                      var delay_1 = Math.max(this.options.minRetryDelay, 1);
                      var nextDelay = delay_1 * this.options.exponentialBase;
                      for (var i = 1; i < failedAttempts; i++) {
                          delay_1 = nextDelay;
                          nextDelay = nextDelay * this.options.exponentialBase;
                          if (nextDelay >= this.options.maxRetryDelay) {
                              nextDelay = this.options.maxRetryDelay;
                              break;
                          }
                      }
                      return (delay_1 +
                          Math.round(Math.random() * (nextDelay - delay_1) +
                              Math.random() * this.options.retryJitter));
                  }
                  // deterministric delay otherwise
                  var delay_2 = Math.max(this.options.minRetryDelay, 1);
                  for (var i = 1; i < failedAttempts; i++) {
                      delay_2 = delay_2 * this.options.exponentialBase;
                      if (delay_2 >= this.options.maxRetryDelay) {
                          delay_2 = this.options.maxRetryDelay;
                          break;
                      }
                  }
                  return delay_2 + Math.round(Math.random() * this.options.retryJitter);
              }
              else if (this.currentDelay) {
                  this.currentDelay = Math.min(Math.max(this.currentDelay * this.options.exponentialBase, 1) +
                      Math.round(Math.random() * this.options.retryJitter), this.options.maxRetryDelay);
              }
              else {
                  this.currentDelay =
                      this.options.minRetryDelay +
                          Math.round(Math.random() * this.options.retryJitter);
              }
              return this.currentDelay;
          }
      };
      RetryStrategyImpl.prototype.success = function () {
          this.currentDelay = undefined;
      };
      return RetryStrategyImpl;
  }());
  /**
   * Creates a new instance of retry strategy.
   * @param options - retry options
   * @returns retry strategy implementation
   */
  function createRetryDelayStrategy(options) {
      return new RetryStrategyImpl(options);
  }

  /* interval between successful retries */
  var RETRY_INTERVAL = 1;
  /**
   * Retries lines up to a limit of max buffer size.
   */
  var RetryBuffer = /** @class */ (function () {
      function RetryBuffer(maxLines, retryLines) {
          this.maxLines = maxLines;
          this.retryLines = retryLines;
          this.size = 0;
          this.nextRetryTime = 0;
          this.closed = false;
          this._timeoutHandle = undefined;
      }
      RetryBuffer.prototype.addLines = function (lines, retryCount, delay, expires) {
          if (this.closed)
              return;
          if (!lines.length)
              return;
          var retryTime = Date.now() + delay;
          if (expires < retryTime) {
              delay = expires - Date.now();
              retryTime = expires;
          }
          if (retryTime > this.nextRetryTime)
              this.nextRetryTime = retryTime;
          // ensure at most maxLines are in the Buffer
          if (this.first && this.size + lines.length > this.maxLines) {
              var origSize = this.size;
              var newSize = origSize * 0.7; // reduce to 70 %
              do {
                  var newFirst = this.first.next;
                  this.size -= this.first.lines.length;
                  this.first.next = undefined;
                  this.first = newFirst;
                  if (!this.first) {
                      this.last = undefined;
                  }
              } while (this.first && this.size + lines.length > newSize);
              Log.error("RetryBuffer: ".concat(origSize - this.size, " oldest lines removed to keep buffer size under the limit of ").concat(this.maxLines, " lines"));
          }
          var toAdd = {
              lines: lines,
              retryCount: retryCount,
              expires: expires,
          };
          if (this.last) {
              this.last.next = toAdd;
              this.last = toAdd;
          }
          else {
              this.first = toAdd;
              this.last = toAdd;
              this.scheduleRetry(delay);
          }
          this.size += lines.length;
      };
      RetryBuffer.prototype.removeLines = function () {
          if (this.first) {
              var toRetry = this.first;
              this.first = this.first.next;
              toRetry.next = undefined;
              this.size -= toRetry.lines.length;
              if (!this.first)
                  this.last = undefined;
              return toRetry;
          }
          return undefined;
      };
      RetryBuffer.prototype.scheduleRetry = function (delay) {
          var _this = this;
          this._timeoutHandle = setTimeout(function () {
              var toRetry = _this.removeLines();
              if (toRetry) {
                  _this.retryLines(toRetry.lines, toRetry.retryCount, toRetry.expires)
                      .then(function () {
                      // continue with successfull retry
                      _this.scheduleRetry(RETRY_INTERVAL);
                  })
                      .catch(function (_e) {
                      // already logged
                      _this.scheduleRetry(_this.nextRetryTime - Date.now());
                  });
              }
              else {
                  _this._timeoutHandle = undefined;
              }
          }, Math.max(delay, 0));
      };
      RetryBuffer.prototype.flush = function () {
          return __awaiter(this, void 0, void 0, function () {
              var toRetry;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          if (!(toRetry = this.removeLines())) return [3 /*break*/, 2];
                          return [4 /*yield*/, this.retryLines(toRetry.lines, toRetry.retryCount, toRetry.expires)];
                      case 1:
                          _a.sent();
                          return [3 /*break*/, 0];
                      case 2: return [2 /*return*/];
                  }
              });
          });
      };
      RetryBuffer.prototype.close = function () {
          if (this._timeoutHandle) {
              clearTimeout(this._timeoutHandle);
              this._timeoutHandle = undefined;
          }
          this.closed = true;
          return this.size;
      };
      return RetryBuffer;
  }());

  /**
   * Utf8Length returns an expected length of a string when UTF-8 encoded.
   * @param s - input string
   * @returns expected count of bytes
   */
  function utf8Length(s) {
      var retVal = s.length;
      // extends the size with code points (https://en.wikipedia.org/wiki/UTF-8#Encoding)
      for (var i = 0; i < s.length; i++) {
          var code = s.charCodeAt(i);
          /* istanbul ignore else - JS does not count with 4-bytes UNICODE characters at the moment */
          if (code < 0x80) {
              continue;
          }
          else if (code >= 0x80 && code <= 0x7ff) {
              retVal++;
          }
          else if (code >= 0x800 && code <= 0xffff) {
              if (code >= 0xd800 && code <= 0xdfff) {
                  // node.js represents unicode characters above 0xffff by two UTF-16 surrogate halves
                  // see https://en.wikipedia.org/wiki/UTF-8#Codepage_layout
                  retVal++;
              }
              else {
                  retVal += 2;
              }
          }
          else {
              // never happens in node.js 14, the situation can vary in the futures or in deno/browsers
              retVal += 3;
          }
      }
      return retVal;
  }

  var WriteBuffer = /** @class */ (function () {
      function WriteBuffer(maxChunkRecords, maxBatchBytes, flushFn, scheduleSend) {
          this.maxChunkRecords = maxChunkRecords;
          this.maxBatchBytes = maxBatchBytes;
          this.flushFn = flushFn;
          this.scheduleSend = scheduleSend;
          this.length = 0;
          this.bytes = -1;
          this.lines = new Array(maxChunkRecords);
      }
      WriteBuffer.prototype.add = function (record) {
          var size = utf8Length(record);
          if (this.length === 0) {
              this.scheduleSend();
          }
          else if (this.bytes + size + 1 >= this.maxBatchBytes) {
              // the new size already exceeds maxBatchBytes, send it
              this.flush().catch(function (_e) {
                  // an error is logged in case of failure, avoid UnhandledPromiseRejectionWarning
              });
          }
          this.lines[this.length] = record;
          this.length++;
          this.bytes += size + 1;
          if (this.length >= this.maxChunkRecords ||
              this.bytes >= this.maxBatchBytes) {
              this.flush().catch(function (_e) {
                  // an error is logged in case of failure, avoid UnhandledPromiseRejectionWarning
              });
          }
      };
      WriteBuffer.prototype.flush = function () {
          var lines = this.reset();
          if (lines.length > 0) {
              return this.flushFn(lines);
          }
          else {
              return Promise.resolve();
          }
      };
      WriteBuffer.prototype.reset = function () {
          var retVal = this.lines.slice(0, this.length);
          this.length = 0;
          this.bytes = -1; // lines are joined with \n
          return retVal;
      };
      return WriteBuffer;
  }());
  var WriteApiImpl = /** @class */ (function () {
      function WriteApiImpl(transport, org, bucket, precision, writeOptions) {
          var _this = this;
          this.transport = transport;
          this.closed = false;
          this._timeoutHandle = undefined;
          this.path = "/api/v2/write?org=".concat(encodeURIComponent(org), "&bucket=").concat(encodeURIComponent(bucket), "&precision=").concat(precision);
          if (writeOptions === null || writeOptions === void 0 ? void 0 : writeOptions.consistency) {
              this.path += "&consistency=".concat(encodeURIComponent(writeOptions.consistency));
          }
          this.writeOptions = __assign(__assign({}, DEFAULT_WriteOptions), writeOptions);
          this.currentTime = currentTime[precision];
          this.dateToProtocolTimestamp = dateToProtocolTimestamp[precision];
          if (this.writeOptions.defaultTags) {
              this.useDefaultTags(this.writeOptions.defaultTags);
          }
          this.sendOptions = {
              method: 'POST',
              headers: __assign({ 'content-type': 'text/plain; charset=utf-8' }, writeOptions === null || writeOptions === void 0 ? void 0 : writeOptions.headers),
              gzipThreshold: this.writeOptions.gzipThreshold,
          };
          var scheduleNextSend = function () {
              if (_this.writeOptions.flushInterval > 0) {
                  _this._clearFlushTimeout();
                  /* istanbul ignore else manually reviewed, hard to reproduce */
                  if (!_this.closed) {
                      _this._timeoutHandle = setTimeout(function () {
                          return _this.sendBatch(_this.writeBuffer.reset(), _this.writeOptions.maxRetries).catch(function (_e) {
                              // an error is logged in case of failure, avoid UnhandledPromiseRejectionWarning
                          });
                      }, _this.writeOptions.flushInterval);
                  }
              }
          };
          // write buffer
          this.writeBuffer = new WriteBuffer(this.writeOptions.batchSize, this.writeOptions.maxBatchBytes, function (lines) {
              _this._clearFlushTimeout();
              return _this.sendBatch(lines, _this.writeOptions.maxRetries);
          }, scheduleNextSend);
          this.sendBatch = this.sendBatch.bind(this);
          // retry buffer
          this.retryStrategy = createRetryDelayStrategy(this.writeOptions);
          this.retryBuffer = new RetryBuffer(this.writeOptions.maxBufferLines, this.sendBatch);
      }
      WriteApiImpl.prototype.sendBatch = function (lines, retryAttempts, expires) {
          var _this = this;
          if (expires === void 0) { expires = Date.now() + this.writeOptions.maxRetryTime; }
          // eslint-disable-next-line @typescript-eslint/no-this-alias
          var self = this;
          var failedAttempts = self.writeOptions.maxRetries + 1 - retryAttempts;
          if (!this.closed && lines.length > 0) {
              if (expires <= Date.now()) {
                  var error = new Error('Max retry time exceeded.');
                  var onRetry = self.writeOptions.writeFailed.call(self, error, lines, failedAttempts, expires);
                  if (onRetry) {
                      return onRetry;
                  }
                  Log.error("Write to InfluxDB failed (attempt: ".concat(failedAttempts, ")."), error);
                  return Promise.reject(error);
              }
              return new Promise(function (resolve, reject) {
                  var responseStatusCode;
                  var callbacks = {
                      responseStarted: function (_headers, statusCode) {
                          responseStatusCode = statusCode;
                      },
                      error: function (error) {
                          // call the writeFailed listener and check if we can retry
                          var onRetry = self.writeOptions.writeFailed.call(self, error, lines, failedAttempts, expires);
                          if (onRetry) {
                              onRetry.then(resolve, reject);
                              return;
                          }
                          // ignore informational message about the state of InfluxDB
                          // enterprise cluster, if present
                          if (error instanceof HttpError &&
                              error.json &&
                              typeof error.json.error === 'string' &&
                              error.json.error.includes('hinted handoff queue not empty')) {
                              Log.warn('Write to InfluxDB returns: ' + error.json.error);
                              responseStatusCode = 204;
                              callbacks.complete();
                              return;
                          }
                          // retry if possible
                          if (!self.closed &&
                              retryAttempts > 0 &&
                              (!(error instanceof HttpError) ||
                                  error.statusCode >= 429)) {
                              Log.warn("Write to InfluxDB failed (attempt: ".concat(failedAttempts, ")."), error);
                              self.retryBuffer.addLines(lines, retryAttempts - 1, self.retryStrategy.nextDelay(error, failedAttempts), expires);
                              reject(error);
                              return;
                          }
                          Log.error("Write to InfluxDB failed.", error);
                          reject(error);
                      },
                      complete: function () {
                          // older implementations of transport do not report status code
                          if (responseStatusCode == 204 || responseStatusCode == undefined) {
                              self.writeOptions.writeSuccess.call(self, lines);
                              self.retryStrategy.success();
                              resolve();
                          }
                          else {
                              var message = "204 HTTP response status code expected, but ".concat(responseStatusCode, " returned");
                              var error = new HttpError(responseStatusCode, message, undefined, '0');
                              error.message = message;
                              callbacks.error(error);
                          }
                      },
                  };
                  _this.transport.send(_this.path, lines.join('\n'), _this.sendOptions, callbacks);
              });
          }
          else {
              return Promise.resolve();
          }
      };
      WriteApiImpl.prototype._clearFlushTimeout = function () {
          if (this._timeoutHandle !== undefined) {
              clearTimeout(this._timeoutHandle);
              this._timeoutHandle = undefined;
          }
      };
      WriteApiImpl.prototype.writeRecord = function (record) {
          if (this.closed) {
              throw new Error('writeApi: already closed!');
          }
          this.writeBuffer.add(record);
      };
      WriteApiImpl.prototype.writeRecords = function (records) {
          if (this.closed) {
              throw new Error('writeApi: already closed!');
          }
          for (var i = 0; i < records.length; i++) {
              this.writeBuffer.add(records[i]);
          }
      };
      WriteApiImpl.prototype.writePoint = function (point) {
          if (this.closed) {
              throw new Error('writeApi: already closed!');
          }
          var line = point.toLineProtocol(this);
          if (line)
              this.writeBuffer.add(line);
      };
      WriteApiImpl.prototype.writePoints = function (points) {
          if (this.closed) {
              throw new Error('writeApi: already closed!');
          }
          for (var i = 0; i < points.length; i++) {
              var line = points[i].toLineProtocol(this);
              if (line)
                  this.writeBuffer.add(line);
          }
      };
      WriteApiImpl.prototype.flush = function (withRetryBuffer) {
          return __awaiter(this, void 0, void 0, function () {
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0: return [4 /*yield*/, this.writeBuffer.flush()];
                      case 1:
                          _a.sent();
                          if (!withRetryBuffer) return [3 /*break*/, 3];
                          return [4 /*yield*/, this.retryBuffer.flush()];
                      case 2: return [2 /*return*/, _a.sent()];
                      case 3: return [2 /*return*/];
                  }
              });
          });
      };
      WriteApiImpl.prototype.close = function () {
          var _this = this;
          var retVal = this.writeBuffer.flush().finally(function () {
              var remaining = _this.retryBuffer.close();
              if (remaining) {
                  Log.error("Retry buffer closed with ".concat(remaining, " items that were not written to InfluxDB!"), null);
              }
              _this.closed = true;
          });
          return retVal;
      };
      WriteApiImpl.prototype.dispose = function () {
          this._clearFlushTimeout();
          this.closed = true;
          return this.retryBuffer.close() + this.writeBuffer.length;
      };
      WriteApiImpl.prototype.useDefaultTags = function (tags) {
          this.defaultTags = tags;
          return this;
      };
      WriteApiImpl.prototype.convertTime = function (value) {
          if (value === undefined) {
              return this.currentTime();
          }
          else if (typeof value === 'string') {
              return value.length > 0 ? value : undefined;
          }
          else if (value instanceof Date) {
              return this.dateToProtocolTimestamp(value);
          }
          else if (typeof value === 'number') {
              return String(Math.floor(value));
          }
          else {
              return String(value);
          }
      };
      return WriteApiImpl;
  }());

  function completeCommunicationObserver(callbacks) {
      if (callbacks === void 0) { callbacks = {}; }
      var state = 0;
      var retVal = {
          next: function (data) {
              if (state === 0 &&
                  callbacks.next &&
                  data !== null &&
                  data !== undefined) {
                  callbacks.next(data);
              }
          },
          error: function (error) {
              /* istanbul ignore else propagate error at most once */
              if (state === 0) {
                  state = 1;
                  /* istanbul ignore else safety check */
                  if (callbacks.error)
                      callbacks.error(error);
              }
          },
          complete: function () {
              if (state === 0) {
                  state = 2;
                  /* istanbul ignore else safety check */
                  if (callbacks.complete)
                      callbacks.complete();
              }
          },
          responseStarted: function (headers, statusCode) {
              if (callbacks.responseStarted)
                  callbacks.responseStarted(headers, statusCode);
          },
      };
      return retVal;
  }

  function getResponseHeaders(response) {
      var headers = {};
      response.headers.forEach(function (value, key) {
          var previous = headers[key];
          if (previous === undefined) {
              headers[key] = value;
          }
          else if (Array.isArray(previous)) {
              previous.push(value);
          }
          else {
              headers[key] = [previous, value];
          }
      });
      return headers;
  }
  /**
   * Transport layer that use browser fetch.
   */
  var FetchTransport = /** @class */ (function () {
      function FetchTransport(connectionOptions) {
          this.connectionOptions = connectionOptions;
          this.chunkCombiner = createTextDecoderCombiner();
          /**
           * RequestDecorator allows to modify requests before sending.
           *
           * The following example shows a function that adds gzip
           * compression of requests using pako.js.
           *
           * ```ts
           * const client = new InfluxDB({url: 'http://a'})
           * client.transport.requestDecorator = function(request, options) {
           *   const body = request.body
           *   if (
           *     typeof body === 'string' &&
           *     options.gzipThreshold !== undefined &&
           *     body.length > options.gzipThreshold
           *   ) {
           *     request.headers['content-encoding'] = 'gzip'
           *     request.body = pako.gzip(body)
           *   }
           * }
           * ```
           */
          this.requestDecorator = function () { };
          this.defaultHeaders = __assign({ 'content-type': 'application/json; charset=utf-8' }, connectionOptions.headers);
          if (this.connectionOptions.token) {
              this.defaultHeaders['Authorization'] =
                  'Token ' + this.connectionOptions.token;
          }
          this.url = String(this.connectionOptions.url);
          if (this.url.endsWith('/')) {
              this.url = this.url.substring(0, this.url.length - 1);
          }
          // https://github.com/influxdata/influxdb-client-js/issues/263
          // don't allow /api/v2 suffix to avoid future problems
          if (this.url.endsWith('/api/v2')) {
              this.url = this.url.substring(0, this.url.length - '/api/v2'.length);
              Log.warn("Please remove '/api/v2' context path from InfluxDB base url, using ".concat(this.url, " !"));
          }
      }
      FetchTransport.prototype.send = function (path, body, options, callbacks) {
          var _this = this;
          var observer = completeCommunicationObserver(callbacks);
          var cancelled = false;
          var signal = options.signal;
          if (callbacks && callbacks.useCancellable) {
              var controller_1 = new AbortController();
              if (!signal) {
                  signal = controller_1.signal;
                  options = __assign(__assign({}, options), signal);
              }
              callbacks.useCancellable({
                  cancel: function () {
                      cancelled = true;
                      controller_1.abort();
                  },
                  isCancelled: function () {
                      return cancelled || signal.aborted;
                  },
              });
          }
          this.fetch(path, body, options)
              .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
              var reader, chunk, buffer, text;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          if (callbacks === null || callbacks === void 0 ? void 0 : callbacks.responseStarted) {
                              observer.responseStarted(getResponseHeaders(response), response.status);
                          }
                          if (!(response.status >= 300)) return [3 /*break*/, 1];
                          return [2 /*return*/, response
                                  .text()
                                  .then(function (text) {
                                  if (!text) {
                                      var headerError = response.headers.get('x-influxdb-error');
                                      if (headerError) {
                                          text = headerError;
                                      }
                                  }
                                  observer.error(new HttpError(response.status, response.statusText, text, response.headers.get('retry-after'), response.headers.get('content-type')));
                              })
                                  .catch(function (e) {
                                  Log.warn('Unable to receive error body', e);
                                  observer.error(new HttpError(response.status, response.statusText, undefined, response.headers.get('retry-after'), response.headers.get('content-type')));
                              })];
                      case 1:
                          if (!response.body) return [3 /*break*/, 6];
                          reader = response.body.getReader();
                          chunk = void 0;
                          _a.label = 2;
                      case 2: return [4 /*yield*/, reader.read()];
                      case 3:
                          chunk = _a.sent();
                          observer.next(chunk.value);
                          _a.label = 4;
                      case 4:
                          if (!chunk.done) return [3 /*break*/, 2];
                          _a.label = 5;
                      case 5: return [3 /*break*/, 10];
                      case 6:
                          if (!response.arrayBuffer) return [3 /*break*/, 8];
                          return [4 /*yield*/, response.arrayBuffer()];
                      case 7:
                          buffer = _a.sent();
                          observer.next(new Uint8Array(buffer));
                          return [3 /*break*/, 10];
                      case 8: return [4 /*yield*/, response.text()];
                      case 9:
                          text = _a.sent();
                          observer.next(new TextEncoder().encode(text));
                          _a.label = 10;
                      case 10: return [2 /*return*/];
                  }
              });
          }); })
              .catch(function (e) {
              if (!cancelled) {
                  observer.error(e);
              }
          })
              .finally(function () { return observer.complete(); });
      };
      FetchTransport.prototype.request = function (path, body, options, responseStarted) {
          var _a, _b;
          return __awaiter(this, void 0, void 0, function () {
              var response, status, headers, responseContentType, data, headerError, responseType;
              return __generator(this, function (_c) {
                  switch (_c.label) {
                      case 0: return [4 /*yield*/, this.fetch(path, body, options)];
                      case 1:
                          response = _c.sent();
                          status = response.status, headers = response.headers;
                          responseContentType = headers.get('content-type') || '';
                          if (responseStarted) {
                              responseStarted(getResponseHeaders(response), response.status);
                          }
                          if (!(status >= 300)) return [3 /*break*/, 3];
                          return [4 /*yield*/, response.text()];
                      case 2:
                          data = _c.sent();
                          if (!data) {
                              headerError = headers.get('x-influxdb-error');
                              if (headerError) {
                                  data = headerError;
                              }
                          }
                          throw new HttpError(status, response.statusText, data, response.headers.get('retry-after'), response.headers.get('content-type'));
                      case 3:
                          responseType = (_b = (_a = options.headers) === null || _a === void 0 ? void 0 : _a.accept) !== null && _b !== void 0 ? _b : responseContentType;
                          if (!responseType.includes('json')) return [3 /*break*/, 5];
                          return [4 /*yield*/, response.json()];
                      case 4: return [2 /*return*/, _c.sent()];
                      case 5:
                          if (!(responseType.includes('text') ||
                              responseType.startsWith('application/csv'))) return [3 /*break*/, 7];
                          return [4 /*yield*/, response.text()];
                      case 6: return [2 /*return*/, _c.sent()];
                      case 7: return [2 /*return*/];
                  }
              });
          });
      };
      FetchTransport.prototype.fetch = function (path, body, options) {
          var method = options.method, headers = options.headers, other = __rest(options, ["method", "headers"]);
          var url = "".concat(this.url).concat(path);
          var request = __assign(__assign({ method: method, body: method === 'GET' || method === 'HEAD'
                  ? undefined
                  : typeof body === 'string'
                      ? body
                      : JSON.stringify(body), headers: __assign(__assign({}, this.defaultHeaders), headers), credentials: 'omit' }, this.connectionOptions.transportOptions), other);
          this.requestDecorator(request, options, url);
          return fetch(url, request);
      };
      return FetchTransport;
  }());

  var DEFAULT_dialect = {
      header: true,
      delimiter: ',',
      quoteChar: '"',
      commentPrefix: '#',
      annotations: ['datatype', 'group', 'default'],
  };
  var QueryApiImpl = /** @class */ (function () {
      function QueryApiImpl(transport, createCSVResponse, org) {
          this.transport = transport;
          this.createCSVResponse = createCSVResponse;
          this.options = typeof org === 'string' ? { org: org } : org;
      }
      QueryApiImpl.prototype.with = function (options) {
          return new QueryApiImpl(this.transport, this.createCSVResponse, __assign(__assign({}, this.options), options));
      };
      QueryApiImpl.prototype.response = function (query) {
          return this.createCSVResponse(this.createExecutor(query));
      };
      QueryApiImpl.prototype.lines = function (query) {
          return this.response(query).lines();
      };
      QueryApiImpl.prototype.rows = function (query) {
          return this.response(query).rows();
      };
      QueryApiImpl.prototype.queryLines = function (query, consumer) {
          return this.response(query).consumeLines(consumer);
      };
      QueryApiImpl.prototype.queryRows = function (query, consumer) {
          return this.response(query).consumeRows(consumer);
      };
      QueryApiImpl.prototype.collectRows = function (query, rowMapper) {
          return this.response(query).collectRows(rowMapper);
      };
      QueryApiImpl.prototype.collectLines = function (query) {
          return this.response(query).collectLines();
      };
      QueryApiImpl.prototype.queryRaw = function (query) {
          var _a = this.options, org = _a.org, type = _a.type, gzip = _a.gzip, headers = _a.headers;
          return this.transport.request("/api/v2/query?org=".concat(encodeURIComponent(org)), JSON.stringify(this.decorateRequest({
              query: query.toString(),
              dialect: DEFAULT_dialect,
              type: type,
          })), {
              method: 'POST',
              headers: __assign({ accept: 'text/csv', 'accept-encoding': gzip ? 'gzip' : 'identity', 'content-type': 'application/json; encoding=utf-8' }, headers),
          });
      };
      QueryApiImpl.prototype.createExecutor = function (query) {
          var _this = this;
          var _a = this.options, org = _a.org, type = _a.type, gzip = _a.gzip, headers = _a.headers;
          return function (consumer) {
              _this.transport.send("/api/v2/query?org=".concat(encodeURIComponent(org)), JSON.stringify(_this.decorateRequest({
                  query: query.toString(),
                  dialect: DEFAULT_dialect,
                  type: type,
              })), {
                  method: 'POST',
                  headers: __assign({ 'content-type': 'application/json; encoding=utf-8', 'accept-encoding': gzip ? 'gzip' : 'identity' }, headers),
              }, consumer);
          };
      };
      QueryApiImpl.prototype.decorateRequest = function (request) {
          var _a;
          if (typeof this.options.now === 'function') {
              request.now = this.options.now();
          }
          // https://docs.influxdata.com/influxdb/v2.1/api/#operation/PostQuery requires type
          request.type = (_a = this.options.type) !== null && _a !== void 0 ? _a : 'flux';
          return request;
      };
      return QueryApiImpl;
  }());

  var QuerySubscription = /** @class */ (function () {
      function QuerySubscription(observer, executor) {
          var _this = this;
          this.isClosed = false;
          try {
              executor({
                  next: function (value) {
                      observer.next(value);
                  },
                  error: function (e) {
                      _this.isClosed = true;
                      observer.error(e);
                  },
                  complete: function () {
                      _this.isClosed = true;
                      observer.complete();
                  },
                  useCancellable: function (c) {
                      _this.cancellable = c;
                  },
              });
          }
          catch (e) {
              this.isClosed = true;
              observer.error(e);
          }
      }
      Object.defineProperty(QuerySubscription.prototype, "closed", {
          get: function () {
              return this.isClosed;
          },
          enumerable: false,
          configurable: true
      });
      QuerySubscription.prototype.unsubscribe = function () {
          var _a;
          (_a = this.cancellable) === null || _a === void 0 ? void 0 : _a.cancel();
          this.isClosed = true;
      };
      return QuerySubscription;
  }());
  function noop() { }
  function completeObserver(observer) {
      var next = observer.next, error = observer.error, complete = observer.complete;
      return {
          next: next ? next.bind(observer) : noop,
          error: error ? error.bind(observer) : noop,
          complete: complete ? complete.bind(observer) : noop,
      };
  }
  var ObservableQuery = /** @class */ (function () {
      function ObservableQuery(executor, decorator) {
          this.executor = executor;
          this.decorator = decorator;
      }
      ObservableQuery.prototype.subscribe = function (observerOrNext, error, complete) {
          var observer = completeObserver(typeof observerOrNext !== 'object' || observerOrNext === null
              ? { next: observerOrNext, error: error, complete: complete }
              : observerOrNext);
          return new QuerySubscription(this.decorator(observer), this.executor);
      };
      ObservableQuery.prototype[symbolObservable] = function () {
          return this;
      };
      return ObservableQuery;
  }());

  function defaultRowMapping(values, tableMeta) {
      return tableMeta.toObject(values);
  }
  /**
   * AnnotatedCsvResponseImpl is an implementation AnnotatedCsvResponse
   * that uses the supplied executor to supply a response data stream.
   */
  var AnnotatedCSVResponseImpl = /** @class */ (function () {
      function AnnotatedCSVResponseImpl(executor, chunkCombiner) {
          this.executor = executor;
          this.chunkCombiner = chunkCombiner;
      }
      AnnotatedCSVResponseImpl.prototype.lines = function () {
          var _this = this;
          return new ObservableQuery(this.executor, function (observer) {
              return chunksToLines(observer, _this.chunkCombiner);
          });
      };
      AnnotatedCSVResponseImpl.prototype.rows = function () {
          var _this = this;
          return new ObservableQuery(this.executor, function (observer) {
              return chunksToLines(linesToTables({
                  next: function (values, tableMeta) {
                      observer.next({ values: values, tableMeta: tableMeta });
                  },
                  error: function (e) {
                      observer.error(e);
                  },
                  complete: function () {
                      observer.complete();
                  },
              }), _this.chunkCombiner);
          });
      };
      AnnotatedCSVResponseImpl.prototype.consumeLines = function (consumer) {
          this.executor(chunksToLines(consumer, this.chunkCombiner));
      };
      AnnotatedCSVResponseImpl.prototype.consumeRows = function (consumer) {
          this.executor(chunksToLines(linesToTables(consumer), this.chunkCombiner));
      };
      AnnotatedCSVResponseImpl.prototype.collectRows = function (rowMapper) {
          var _this = this;
          if (rowMapper === void 0) { rowMapper = defaultRowMapping; }
          var retVal = [];
          return new Promise(function (resolve, reject) {
              _this.consumeRows({
                  next: function (values, tableMeta) {
                      var toAdd = rowMapper.call(this, values, tableMeta);
                      if (toAdd !== undefined) {
                          retVal.push(toAdd);
                      }
                  },
                  error: function (error) {
                      reject(error);
                  },
                  complete: function () {
                      resolve(retVal);
                  },
              });
          });
      };
      AnnotatedCSVResponseImpl.prototype.collectLines = function () {
          var _this = this;
          var retVal = [];
          return new Promise(function (resolve, reject) {
              _this.consumeLines({
                  next: function (line) {
                      retVal.push(line);
                  },
                  error: function (error) {
                      reject(error);
                  },
                  complete: function () {
                      resolve(retVal);
                  },
              });
          });
      };
      return AnnotatedCSVResponseImpl;
  }());

  /**
   * InfluxDB entry point that configures communication with InfluxDB server
   * and provide APIs to write and query data.
   */
  var InfluxDB = /** @class */ (function () {
      /**
       * Creates influxdb client options from an options object or url.
       * @param options - client options
       */
      function InfluxDB(options) {
          var _this = this;
          var _a;
          if (typeof options === 'string') {
              this._options = { url: options };
          }
          else if (options !== null && typeof options === 'object') {
              this._options = options;
          }
          else {
              throw new IllegalArgumentError('No url or configuration specified!');
          }
          var url = this._options.url;
          if (typeof url !== 'string')
              throw new IllegalArgumentError('No url specified!');
          if (url.endsWith('/'))
              this._options.url = url.substring(0, url.length - 1);
          this.transport = (_a = this._options.transport) !== null && _a !== void 0 ? _a : new FetchTransport(this._options);
          this.processCSVResponse = function (executor) {
              return new AnnotatedCSVResponseImpl(executor, _this.transport.chunkCombiner);
          };
      }
      /**
       * Creates WriteApi for the supplied organization and bucket. BEWARE that returned instances must be closed
       * in order to flush the remaining data and close already scheduled retry executions.
       *
       * @remarks
       * Inspect the {@link WriteOptions} to control also advanced options, such retries of failure, retry strategy options, data chunking
       * and flushing windows. See {@link DEFAULT_WriteOptions} to see the defaults.
       *
       * See also {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/write.js | write.js example},
       * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/writeAdvanced.js | writeAdvanced.js example},
       * and {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/index.html | browser example}.
       *
       * @param org - Specifies the destination organization for writes. Takes either the ID or Name interchangeably.
       * @param bucket - The destination bucket for writes.
       * @param precision - Timestamp precision for line items.
       * @param writeOptions - Custom write options.
       * @returns WriteApi instance
       */
      InfluxDB.prototype.getWriteApi = function (org, bucket, precision, writeOptions) {
          if (precision === void 0) { precision = 'ns'; }
          return new WriteApiImpl(this.transport, org, bucket, precision, writeOptions !== null && writeOptions !== void 0 ? writeOptions : this._options.writeOptions);
      };
      /**
       * Creates QueryApi for the supplied organization .
       *
       * @remarks
       * See also {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/query.ts | query.ts example},
       * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/queryWithParams.ts | queryWithParams.ts example},
       * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/rxjs-query.ts | rxjs-query.ts example},
       * and {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/index.html | browser example},
       *
       * @param org - organization or query options
       * @returns QueryApi instance
       */
      InfluxDB.prototype.getQueryApi = function (org) {
          return new QueryApiImpl(this.transport, this.processCSVResponse, org);
      };
      return InfluxDB;
  }());

  exports.AbortError = AbortError;
  exports.DEFAULT_ConnectionOptions = DEFAULT_ConnectionOptions;
  exports.DEFAULT_RetryDelayStrategyOptions = DEFAULT_RetryDelayStrategyOptions;
  exports.DEFAULT_WriteOptions = DEFAULT_WriteOptions;
  exports.FLUX_VALUE = FLUX_VALUE;
  exports.HttpError = HttpError;
  exports.IllegalArgumentError = IllegalArgumentError;
  exports.InfluxDB = InfluxDB;
  exports.LineSplitter = LineSplitter;
  exports.Log = Log;
  exports.Point = Point;
  exports.RequestTimedOutError = RequestTimedOutError;
  exports.UNKNOWN_COLUMN = UNKNOWN_COLUMN;
  exports.canRetryHttpCall = canRetryHttpCall;
  exports.chunksToLines = chunksToLines;
  exports.consoleLogger = consoleLogger;
  exports.convertTimeToNanos = convertTimeToNanos;
  exports.createFluxTableColumn = createFluxTableColumn;
  exports.createFluxTableMetaData = createFluxTableMetaData;
  exports.createTextDecoderCombiner = createTextDecoderCombiner;
  exports.currentTime = currentTime;
  exports.dateToProtocolTimestamp = dateToProtocolTimestamp;
  exports.escape = escape;
  exports.flux = flux;
  exports.fluxBool = fluxBool;
  exports.fluxDateTime = fluxDateTime;
  exports.fluxDuration = fluxDuration;
  exports.fluxExpression = fluxExpression;
  exports.fluxFloat = fluxFloat;
  exports.fluxInteger = fluxInteger;
  exports.fluxRegExp = fluxRegExp;
  exports.fluxString = fluxString;
  exports.getRetryDelay = getRetryDelay;
  exports.isStatusCodeRetriable = isStatusCodeRetriable;
  exports.linesToTables = linesToTables;
  exports.newFluxTableColumn = newFluxTableColumn;
  exports.sanitizeFloat = sanitizeFloat;
  exports.sanitizeInteger = sanitizeInteger;
  exports.serializeDateTimeAsDate = serializeDateTimeAsDate;
  exports.serializeDateTimeAsNumber = serializeDateTimeAsNumber;
  exports.serializeDateTimeAsString = serializeDateTimeAsString;
  exports.setLogger = setLogger;
  exports.stringToLines = stringToLines;
  exports.symbolObservable = symbolObservable;
  exports.toFluxValue = toFluxValue;
  exports.typeSerializers = typeSerializers;
  exports.useProcessHrtime = useProcessHrtime;

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;

})({});
//# sourceMappingURL=influxdb.js.map
